// Módulo vacío para ignorar dependencias de test como `tap` y `why-is-node-running`
module.exports = {};
