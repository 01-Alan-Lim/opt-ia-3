// mock-empty-module.js
// Módulo vacío para que Turbopack resuelva dependencias de test (tap, why-is-node-running)
module.exports = {};
