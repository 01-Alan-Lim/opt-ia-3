// src/empty-module.ts
// Módulo “fake” para dependencias de test/logging que rompen el build.
// Todo lo que lo importe recibirá simplemente un objeto vacío.

export default {};
