// src/app/api/plans/ishikawa/validate/route.ts
import { NextResponse } from "next/server";
import { ok, fail } from "@/lib/api/response";
import { getAuthErrorCode, requireUser } from "@/lib/auth/supabase";
import { supabaseServer } from "@/lib/supabaseServer";
import { getGeminiModel } from "@/lib/geminiClient";
import { z } from "zod";
import { PLAN_STAGE_ARTIFACTS_ON_CONFLICT } from "@/lib/db/planArtifacts";
import { getPeriodKeyLaPaz } from "@/lib/time/periodKey";
import { assertChatAccess } from "@/lib/auth/chatAccess";
import { advancePlanStage } from "@/lib/plan/stageOrchestrator";

export const runtime = "nodejs";

const STAGE = 4;
const DraftType = "ishikawa_wizard_state";
const FinalType = "ishikawa_final";
const PERIOD_KEY = getPeriodKeyLaPaz();

const BodySchema = z.object({
  chatId: z.string().uuid(),
});

function extractJsonSafe(text: string) {
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  try {
    return JSON.parse(cleaned);
  } catch {}
  const match = cleaned.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    return JSON.parse(match[0]);
  } catch {
    return null;
  }
}

function countRootCandidates(state: any) {
  const cats = Array.isArray(state?.categories) ? state.categories : [];
  const roots: string[] = [];

  for (const c of cats) {
    const mains = Array.isArray(c?.mainCauses) ? c.mainCauses : [];

    for (const m of mains) {
      const subs = Array.isArray(m?.subCauses) ? m.subCauses : [];

      for (const s of subs) {
        const whys = Array.isArray(s?.whys) ? s.whys : [];

        const normalizedWhys = whys
          .map((w: any) => (typeof w === "string" ? w : (w?.text ?? "")))
          .map((t: any) => (t ?? "").toString().trim())
          .filter(Boolean);

        if (normalizedWhys.length > 0) {
          const last = normalizedWhys[normalizedWhys.length - 1];
          if (last) roots.push(last);
          continue;
        }

        const t = (s?.text ?? s?.name ?? "").toString().trim();
        if (t) roots.push(t);
      }
    }
  }

  return roots;
}

function buildScore(state: any, roots: string[]) {
  // Score simple y explicable (sin cambiar tu lógica):
  // - base: 40 si hay problemática
  // - +15 si cumple min categorías
  // - +15 si cumple min main/sub (si llega aquí, cumple)
  // - +30 proporcional por raíces (10 → 30 pts, 15+ → 30 pts)
  const problemText =
    typeof state?.problem === "string"
      ? state.problem
      : typeof state?.problem?.text === "string"
        ? state.problem.text
        : "";

  const hasProblem = Boolean(problemText?.trim());
  const cats = Array.isArray(state?.categories) ? state.categories : [];
  const minCats = typeof state?.minCategories === "number" ? state.minCategories : 4;

  const total =
    (hasProblem ? 40 : 0) +
    (cats.length >= minCats ? 15 : 0) +
    15 +
    Math.min(30, Math.round((Math.min(roots.length, 15) / 10) * 30));

  return {
    total: Math.min(100, Math.max(0, total)),
    rootsCount: roots.length,
    categoriesCount: cats.length,
    period_key: PERIOD_KEY,
    stage: STAGE,
  };
}


export async function POST(req: Request) {
  try {
    const authed = await requireUser(req);

    const gate = await assertChatAccess(req, authed);
    if (!gate.ok) {
      return NextResponse.json(fail("FORBIDDEN", gate.message), { status: 403 });
    }

    const userId = authed.userId;

    const raw = await req.json().catch(() => null);
    const parsed = BodySchema.safeParse(raw);
    if (!parsed.success) {
      return NextResponse.json(fail("BAD_REQUEST", "Falta chatId"), { status: 400 });
    }
    const { chatId } = parsed.data;




    // 1) Leer estado vivo desde plan_stage_states
    let stateRow: { state_json: Record<string, unknown> | null; chat_id: string | null } | null = null;

    const direct = await supabaseServer
      .from("plan_stage_states")
      .select("state_json, chat_id")
      .eq("user_id", userId)
      .eq("chat_id", chatId)
      .eq("stage", STAGE)
      .maybeSingle();

    if (direct.error) {
      return NextResponse.json(fail("BAD_REQUEST", direct.error.message), { status: 400 });
    }

    stateRow = direct.data ?? null;

    if (!stateRow && !chatId) {
      const latest = await supabaseServer
        .from("plan_stage_states")
        .select("state_json, chat_id")
        .eq("user_id", userId)
        .eq("stage", STAGE)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (latest.error) {
        return NextResponse.json(fail("BAD_REQUEST", latest.error.message), { status: 400 });
      }

      stateRow = latest.data ?? null;
    }

    // Compatibilidad temporal: fallback legacy
    let legacyRow: { payload: Record<string, unknown> | null; chat_id: string | null } | null = null;

    if (!stateRow?.state_json) {
      const legacyDirect = await supabaseServer
        .from("plan_stage_artifacts")
        .select("payload, chat_id")
        .eq("user_id", userId)
        .eq("chat_id", chatId)
        .eq("stage", STAGE)
        .eq("artifact_type", DraftType)
        .eq("period_key", PERIOD_KEY)
        .maybeSingle();

      if (legacyDirect.error) {
        return NextResponse.json(fail("BAD_REQUEST", legacyDirect.error.message), { status: 400 });
      }

      legacyRow = legacyDirect.data ?? null;

      if (!legacyRow && !chatId) {
        const legacyLatest = await supabaseServer
          .from("plan_stage_artifacts")
          .select("payload, chat_id")
          .eq("user_id", userId)
          .eq("stage", STAGE)
          .eq("artifact_type", DraftType)
          .eq("period_key", PERIOD_KEY)
          .order("updated_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (legacyLatest.error) {
          return NextResponse.json(fail("BAD_REQUEST", legacyLatest.error.message), { status: 400 });
        }

        legacyRow = legacyLatest.data ?? null;
      }
    }

    const s: any = stateRow?.state_json ?? legacyRow?.payload ?? null;
    const stateChatId = stateRow?.chat_id ?? legacyRow?.chat_id ?? null;

    if (!s) {
      return NextResponse.json(fail("BAD_REQUEST", "No hay estado de Etapa 4"), { status: 400 });
    }



    // 2) validaciones mínimas (las mismas que ya tenías)
    const problemText =
      typeof s?.problem === "string"
        ? s.problem
        : typeof s?.problem?.text === "string"
          ? s.problem.text
          : "";

    if (!problemText.trim()) {
      return ok({ valid: false, message: "Falta la problemática (cabeza del Ishikawa)." });
    }

    const cats = Array.isArray(s?.categories) ? s.categories : [];

    // ✅ Nuevas reglas (si el state trae números, los usa; si no, usa defaults nuevos)
    const minCats = typeof s?.minCategories === "number" ? s.minCategories : 3;
    const minMain = typeof s?.minMainCausesPerCategory === "number" ? s.minMainCausesPerCategory : 2;
    const minSub = typeof s?.minSubCausesPerMain === "number" ? s.minSubCausesPerMain : 1;
    const minRoots =
    typeof s?.minRootCandidates === "number"
      ? s.minRootCandidates
      : Math.max(1, minCats * minMain);

    const isPlaceholder = (x: any) => {
      const t = (x ?? "").toString().trim().toLowerCase();
      return !t || t === "causa" || t === "subcausa";
    };

    const normalizeWhys = (sc: any) => {
      const whys = Array.isArray(sc?.whys) ? sc.whys : [];
      return whys
        .map((w: any) => (typeof w === "string" ? w : (w?.text ?? "")))
        .map((t: any) => (t ?? "").toString().trim())
        .filter(Boolean);
    };

    const isSubValid = (sc: any) => {
      const n = (sc?.name ?? sc?.text ?? "").toString().trim();
      if (n && !isPlaceholder(n)) return true;
      return normalizeWhys(sc).length > 0;
    };

    // ✅ Una causa principal “completa” = tiene ≥ minSub subcausas válidas
    const isMainComplete = (mc: any) => {
      const subs = Array.isArray(mc?.subCauses) ? mc.subCauses : [];
      const validSubs = subs.filter(isSubValid);
      return validSubs.length >= minSub;
    };

    // ✅ Conteo por categoría: cuántas causas principales completas tiene
    const mainCompleteCount = (cat: any) => {
      const mains = Array.isArray(cat?.mainCauses) ? cat.mainCauses : [];
      return mains.filter(isMainComplete).length;
    };

    // ✅ Categoría completa = tiene ≥ minMain causas principales completas
    const completeCats = cats.filter((c: any) => mainCompleteCount(c) >= minMain);

    if (completeCats.length < minCats) {
      const statusPerCat = cats
        .map((c: any) => `${c?.name ?? "Categoría"}: ${mainCompleteCount(c)}/${minMain}`)
        .join(" | ");

      return NextResponse.json(
        ok({
          valid: false,
          message:
            `Aún no cumples el mínimo de categorías completas: ` +
            `${completeCats.length}/${minCats}. ` +
            `Debes completar ${minCats} categorías con ≥${minMain} causas principales completas (y cada una con ≥${minSub} subcausa válida).`,
          detail: { statusPerCat },
        })
      );
    }

    const roots = Array.from(
      new Set(
        countRootCandidates(s)
          .map((r: any) => (r ?? "").toString().trim())
          .filter(Boolean)
      )
    );

    if (roots.length < minRoots) {
      return NextResponse.json(
        ok({
          valid: false,
          message:
            `Aún hay pocas causas raíz/candidatas (${roots.length}/${minRoots}). ` +
            `Completa al menos ${minRoots} (recomendado 10–15) para pasar a Pareto.`,
        })
      );
    }

    // 3) preparar payload final + score estructural (se mantiene)
    const finalPayload = {
      ...s,
      validatedAt: new Date().toISOString(),
      roots,
    };
    const score = buildScore(s, roots);

    // 4) upsert final artifact (NO depende de chat_id para evitar duplicate key al abrir nuevo chat)
    const { data: finalRow, error: upErr } = await supabaseServer
      .from("plan_stage_artifacts")
      .upsert(
        {
          user_id: userId,
          chat_id: chatId ?? stateChatId ?? null,
          stage: STAGE,
          artifact_type: FinalType,
          period_key: PERIOD_KEY,
          status: "validated",
          payload: finalPayload,
          score,
          updated_at: new Date().toISOString(),
        },
        { onConflict: PLAN_STAGE_ARTIFACTS_ON_CONFLICT }
      )
      .select("id")
      .single();

    if (upErr || !finalRow) {
      return NextResponse.json(fail("BAD_REQUEST", upErr?.message ?? "No se pudo guardar final"), { status: 400 });
    }

    const finalArtifactId = finalRow.id as string;

    // 5) Evaluación pedagógica IA (estilo E2/E3)
    const model = getGeminiModel();
    const rubric = {
      estructura: 30,
      trazabilidad_5pq: 40,
      calidad_claridad: 30,
    };

    const prompt = `
Evalúa académicamente la Etapa 4 (Diagrama de Ishikawa + análisis de 5 Porqués).

RÚBRICA:
1) Estructura y completitud del diagrama (30%):
   - Categorías bien definidas y coherentes con el proceso/área
   - Ramas con causas/subcausas suficientes y no vacías
2) Trazabilidad del análisis 5 Porqués (40%):
   - Las ramas siguen lógica causa → causa más profunda
   - Se identifica cuándo una causa es raíz (accionable/controlable)
   - Evita saltos lógicos
3) Calidad y claridad de las causas (30%):
   - Causas específicas, no genéricas
   - Sin duplicados evidentes
   - Útiles para priorizar luego en Pareto

Escala fija: Deficiente / Regular / Adecuado / Bien

Devuelve SOLO JSON:
{
  "total_score": number (0-100),
  "total_label": "Deficiente" | "Regular" | "Adecuado" | "Bien",
  "detail": {
    "estructura": number,
    "trazabilidad_5pq": number,
    "calidad_claridad": number
  },
  "feedback": "string",
  "mejoras": ["string", "string", "string"]
}

ENTREGA DEL ESTUDIANTE:
${JSON.stringify(
  {
    problem: finalPayload?.problem ?? null,
    categories: finalPayload?.categories ?? [],
    roots: finalPayload?.roots ?? [],
  },
  null,
  2
)}
`;

    const llmRes = await model.generateContent(prompt);
    const llmText = llmRes.response.text();
    const evaluation = extractJsonSafe(llmText);

    // Si la IA falla, NO bloqueamos: la etapa ya está validada estructuralmente.
    // Igual devolvemos warning.
    let evalWarning: { warning: string; raw?: string } | null = null;

    if (!evaluation || typeof evaluation.total_score !== "number") {
      evalWarning = { warning: "Etapa 4 validada, pero la IA no devolvió un JSON válido.", raw: llmText };
    } else {
      // ✅ Evitar duplicar evaluaciones (patrón E3)
      const { data: existingEval, error: existingEvalErr } = await supabaseServer
        .from("plan_stage_evaluations")
        .select("id")
        .eq("user_id", userId)
        .eq("stage", STAGE)
        .eq("artifact_type", FinalType)
        .eq("period_key", PERIOD_KEY)
        .eq("artifact_id", finalArtifactId)
        .maybeSingle();

      if (existingEvalErr) {
        evalWarning = { warning: "Etapa 4 validada, pero no se pudo verificar evaluación existente." };
      } else if (!existingEval) {
        const payloadEval = { status: "validated", rootsCount: roots.length };

        const { error: evalInsErr } = await supabaseServer.from("plan_stage_evaluations").insert({
          user_id: userId,
          chat_id: chatId ?? stateChatId ?? null,
          stage: STAGE,
          artifact_type: FinalType,
          artifact_id: finalArtifactId,
          period_key: PERIOD_KEY,

          // ✅ mantenemos lo que ya tenías:
          status: "validated",
          payload_json: payloadEval,

          // ✅ añadimos rúbrica IA estilo E2/E3:
          rubric_json: rubric,
          result_json: evaluation,
          total_score: evaluation.total_score,
          total_label: evaluation.total_label,
        });

        if (evalInsErr) {
          evalWarning = { warning: "Etapa 4 validada, pero no se pudo insertar la evaluación IA." };
        }
      }
    }

    const next = await advancePlanStage({
      userId,
      chatId: chatId ?? stateChatId ?? null,
      fromStage: STAGE,
    });

    return ok({
      valid: true,
      message: "Etapa 4 validada.",
      roots,
      score,
      evaluation: evaluation && typeof evaluation.total_score === "number" ? evaluation : null,
      ...(evalWarning ? { warning: evalWarning.warning, warningRaw: evalWarning.raw } : {}),
      next,
    });
    } catch (err: unknown) {
    const authCode = getAuthErrorCode(err);

    if (authCode === "UNAUTHORIZED") {
      return NextResponse.json(fail("UNAUTHORIZED", "Sesión inválida o ausente."), { status: 401 });
    }

    if (authCode === "FORBIDDEN_DOMAIN") {
      return NextResponse.json(fail("FORBIDDEN_DOMAIN", "Correo no permitido."), { status: 403 });
    }

    if (authCode === "AUTH_UPSTREAM_TIMEOUT") {
      return NextResponse.json(
        fail(
          "AUTH_UPSTREAM_TIMEOUT",
          "No se pudo validar tu sesión por un timeout temporal con el servicio de autenticación."
        ),
        { status: 503 }
      );
    }

    if (err instanceof z.ZodError) {
      return NextResponse.json(
        fail("BAD_REQUEST", err.issues[0]?.message ?? "Payload inválido."),
        { status: 400 }
      );
    }

    return NextResponse.json(fail("INTERNAL", "Error interno."), { status: 500 });
  }
}
