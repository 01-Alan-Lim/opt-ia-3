import { NextRequest } from "next/server"
import { z } from "zod"
import { ok, fail } from "@/lib/http"
import { requireUser } from "@/lib/auth/requireUser"
import { runTeacherChatAgent } from "@/lib/teacher/chat/agent"

export const runtime = "nodejs"

const BodySchema = z.object({
  message: z.string().min(1),
  context: z.object({
    studentId: z.string().optional(),
    studentName: z.string().optional(),
    ru: z.string().optional(),
    stage: z.number().optional(),
  }).optional()
})

export async function POST(req: NextRequest) {

  const user = await requireUser()

  if (!user) {
    return fail("Unauthorized", 401)
  }

  const body = await req.json()
  const parsed = BodySchema.safeParse(body)

  if (!parsed.success) {
    return fail("Invalid request", 400)
  }

  const { message, context } = parsed.data

  const result = await runTeacherChatAgent(
    message,
    context ?? {}
  )

  return ok(result)
}