import { getGeminiModel } from "@/lib/ai/gemini"
import { findStudentsByTerm, getChatsCount, getMessagesCount, getHoursTotal } from "./tools"
import type { TeacherChatContext, TeacherRouter } from "./types"

export async function runTeacherChatAgent(
  message: string,
  context: TeacherChatContext
) {

  const model = getGeminiModel()

  const routerPrompt = `
Eres un asistente académico para docentes de Ingeniería de Métodos.

Analiza la pregunta del docente y responde con JSON.

Tipos de intención:
student_report
student_hours
student_stages
usage_summary
progress_summary
top_students
alerts
clarify

Devuelve JSON:
{
 intent,
 confidence,
 needsStudent,
 studentTerm
}

Pregunta:
${message}
`

  const routerResult = await model.generateContent(routerPrompt)
  const text = routerResult.response.text()

  let router: TeacherRouter

  try {
    router = JSON.parse(text)
  } catch {
    return {
      message: "No pude interpretar la consulta del docente.",
      context,
    }
  }

  if (router.needsStudent && router.studentTerm) {

    const matches = await findStudentsByTerm(router.studentTerm)

    if (matches.length === 0) {
      return {
        message:
          "No encontré al estudiante. Puedes dar RU, email o nombre completo.",
        context,
      }
    }

    if (matches.length > 1) {
      const list = matches
        .map(s => `• ${s.full_name} (RU ${s.ru})`)
        .join("\n")

      return {
        message:
          `Encontré varios estudiantes:\n\n${list}\n\nIndica cuál deseas analizar.`,
        context,
      }
    }

    const student = matches[0]

    const chats = await getChatsCount(student.id)
    const messages = await getMessagesCount(student.id)
    const hours = await getHoursTotal(student.id)

    const responsePrompt = `
Eres un asistente académico.

Resume estos datos para un docente.

Estudiante: ${student.full_name}
RU: ${student.ru}

Chats: ${chats}
Mensajes: ${messages}
Horas registradas: ${hours}

Responde con un pequeño análisis.
`

    const response = await model.generateContent(responsePrompt)

    return {
      message: response.response.text(),
      context: {
        studentId: student.id,
        studentName: student.full_name ?? undefined,
        ru: student.ru ?? undefined,
      },
    }
  }

  return {
    message: "¿Podrías dar más detalles sobre el estudiante?",
    context,
  }
}