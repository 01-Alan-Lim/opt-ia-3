import { supabaseServer } from "@/lib/supabase/server"
import type { ProfileStudent } from "./types"

export async function findStudentsByTerm(term: string): Promise<ProfileStudent[]> {
  const supabase = supabaseServer()

  const { data } = await supabase
    .from("profiles")
    .select("id, ru, full_name, email")
    .or(
      `full_name.ilike.%${term}%,email.ilike.%${term}%,ru.ilike.%${term}%`
    )
    .limit(5)

  return (data || []) as ProfileStudent[]
}

export async function loadStudentById(userId: string): Promise<ProfileStudent | null> {
  const supabase = supabaseServer()

  const { data } = await supabase
    .from("profiles")
    .select("id, ru, full_name, email")
    .eq("id", userId)
    .single()

  return data ?? null
}

export async function getChatsCount(userId: string): Promise<number> {
  const supabase = supabaseServer()

  const { count } = await supabase
    .from("chats")
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId)

  return count ?? 0
}

export async function getMessagesCount(userId: string): Promise<number> {
  const supabase = supabaseServer()

  const { count } = await supabase
    .from("messages")
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId)

  return count ?? 0
}

export async function getHoursTotal(userId: string): Promise<number> {
  const supabase = supabaseServer()

  const { data } = await supabase
    .from("weekly_hours")
    .select("hours")
    .eq("user_id", userId)

  return (data || []).reduce((sum, r) => sum + (r.hours || 0), 0)
}